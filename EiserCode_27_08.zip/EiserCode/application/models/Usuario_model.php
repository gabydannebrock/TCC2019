<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario_model extends CI_Model {

    public function validaLogin($email, $senha){
        $teste = $this->db->get_where('Usuario', array('email' => $email))->result_array();
        $conta = $teste[0];
        if (empty($conta)) {
            return false;
        }else{
            if ($senha == $conta['Senha']) {
                $retorna = array(
                    'nome' => $conta['Nome'],
                    'email' => $conta['Email']
                );
                return $retorna;
            }else{
                return false;
            }
        }
    }

    public function validaCadastro($user){
        //var_dump ($user);
        $this->db
            ->select('*')
            ->where('Nome', $user['nome'])
            ->where('Senha', $user['senha'])
            ->where('Email', $user['email'])
            ->where('CPF', $user['cpf'])
            ->where('RG', $user['rg'])
            ->where('tipoUser', $user['tipoUser']);

        $usuario = $this->db->get('Usuario')->result_array();
        //$usuario = $this->db->get('Usuario');
        //var_dump($usuario);

        //if ($this->db->get('Usuario')->result_array()) {
        //    return FALSE;
        //}else{
        //    $this->db->insert('Usuario', $user);
        //    return TRUE;
        //}
        if ($usuario) {
            return FALSE;
        }else{
            $this->db->insert('Usuario', $user);
            return TRUE;
        }

    }

    public function recebeDados($email){
        $this->db
            ->where('email', $email);
        $user = $this->db->get('Usuario')->result_array();
        $this->db
            ->where('Cod_Tip_User', $user[0]['tipoUser'])
            ->select('Descricao');
        $tipo = $this->db->get('Tip_User')->result_array();
        $user[0]['tipoUser'] = $tipo[0]['Descricao'];
        return $user[0];
    }
}

?>