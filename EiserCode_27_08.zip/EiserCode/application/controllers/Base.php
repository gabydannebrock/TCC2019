<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Base extends CI_Controller {

	public function __construct(){
		parent::__construct();
		session_start();
		$this->load->model('Usuario_model');
	}

	public function index(){
		$this->load->view('cabecalho');
		$this->load->view('home');	
	}
	public function perfil(){
		$dados = $this->Usuario_model->recebeDados($_SESSION['email']);
		$this->load->view('cabecalho');
        $this->load->view('perfil', $dados);
    }

	public function login(){
		$this->load->helper('form');
		//Regras de validação
		$this->load->library('form_validation');
		$this->load->view('cabecalho');
		$this->load->view('login');
	}
	public function cadastro(){
		$this->load->helper('form');
		//Regras de validação
		$this->load->library('form_validation');
		$this->load->view('cabecalho');
		$this->load->view('cadastro');
	}

	public function validaLogin(){
		$this->load->helper('form');
		//Regras de validação
		$this->load->library('form_validation');
		$this->form_validation->set_rules('email', 'E-mail', 'trim|required');
		$this->form_validation->set_rules('senha', 'Senha', 'trim|required');

		if ($this->form_validation->run() == FALSE){
			$dados['formerror'] = validation_errors();
			header("refresh: 0;".site_url('Base/login'));
			redirect('index.php/login');
		}else{

			$dadosForm = $this->input->post();
			$dados['formerror'] = null;
			$model = $this->Usuario_model->validaLogin($dadosForm['email'], $dadosForm['senha']);
			if (empty($model)) {
				
			}else{
				$_SESSION['nome'] = $model['nome'];
				$_SESSION['email'] = $model['email'];
                redirect('../index.php');
			}
		}
		//header("refresh: 0;".base_url('index'));
	}

	public function logout(){
		session_destroy();
		header("refresh: 0;".site_url('Base/index'));
	}

	public function validaCadastro(){
		$user['nome'] = $_POST['nome'];
		$user['senha'] = $_POST['senha'];
		$user['email'] = $_POST['email'];
		$user['cpf'] = $_POST['cpf'];
		$user['rg'] = $_POST['rg'];
		//$user['tipoUser'] = $_POST['tipoUser'];
		$tipo_user = $_POST['tipoUser'];

        if ($tipo_user == 'veterinario')
        {
            $user['tipoUser'] = 1;
        }

        if ($tipo_user == 'servidor')
        {
            $user['tipoUser'] = 2;
        }
        //echo $user['tipoUser'];

		if ($this->Usuario_model->validaCadastro($user)) {
            redirect('../index.php');

		}else{
			return false;
		}
	}
}
