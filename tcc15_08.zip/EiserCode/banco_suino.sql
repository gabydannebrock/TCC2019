-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 17/06/2019 às 18:53
-- Versão do servidor: 5.7.26-0ubuntu0.18.04.1
-- Versão do PHP: 7.2.10-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `banco_suino`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `Baia`
--

CREATE TABLE `Baia` (
  `Cod_Baia` int(4) NOT NULL,
  `Tamanho` varchar(10) NOT NULL,
  `Qtd_Animal` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Cad_Animal`
--

CREATE TABLE `Cad_Animal` (
  `Cod_Animal` int(4) NOT NULL,
  `Descricao` varchar(500) DEFAULT NULL,
  `Peso` int(3) NOT NULL,
  `Escore` int(1) NOT NULL,
  `Qtd_Racao` int(7) NOT NULL,
  `Idade` int(4) NOT NULL,
  `Gestacao` varchar(500) NOT NULL,
  `Baia_Cod_Baia` int(4) NOT NULL,
  `Est_Cod_Estoque` int(4) NOT NULL,
  `Usuario_Cod_Usuario` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Est_Racao`
--

CREATE TABLE `Est_Racao` (
  `Cod_Estoque` int(4) NOT NULL,
  `Qtd_Racao` int(11) NOT NULL,
  `Nome_Racao` varchar(500) NOT NULL,
  `Usuario_Est_Cod_Usuario` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura para tabela `Tip_User`
--

CREATE TABLE `Tip_User` (
  `Cod_Tip_User` int(4) NOT NULL,
  `Descricao` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `Tip_User`
--

INSERT INTO `Tip_User` (`Cod_Tip_User`, `Descricao`) VALUES
(1, 'Veterinario');

-- --------------------------------------------------------

--
-- Estrutura para tabela `Usuario`
--

CREATE TABLE `Usuario` (
  `Cod_Usuario` int(4) NOT NULL,
  `Nome` varchar(100) NOT NULL,
  `Senha` varchar(10) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `RG` varchar(100) NOT NULL,
  `CPF` varchar(100) NOT NULL,
  `tipoUser` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Fazendo dump de dados para tabela `Usuario`
--

INSERT INTO `Usuario` (`Cod_Usuario`, `Nome`, `Senha`, `Email`, `RG`, `CPF`, `tipoUser`) VALUES
(3, 'nego', '111', 'nego@gmail.com', '1.111.111', '123.555.333-21', 1);

--
-- Índices de tabelas apagadas
--

--
-- Índices de tabela `Baia`
--
ALTER TABLE `Baia`
  ADD PRIMARY KEY (`Cod_Baia`);

--
-- Índices de tabela `Cad_Animal`
--
ALTER TABLE `Cad_Animal`
  ADD PRIMARY KEY (`Cod_Animal`),
  ADD KEY `Baia_Cod_Baia` (`Baia_Cod_Baia`),
  ADD KEY `Est_Cod_Estoque` (`Est_Cod_Estoque`),
  ADD KEY `Usuario_Cod_Usuario` (`Usuario_Cod_Usuario`);

--
-- Índices de tabela `Est_Racao`
--
ALTER TABLE `Est_Racao`
  ADD PRIMARY KEY (`Cod_Estoque`),
  ADD KEY `Usuario_Est_Cod_Usuario` (`Usuario_Est_Cod_Usuario`);

--
-- Índices de tabela `Tip_User`
--
ALTER TABLE `Tip_User`
  ADD PRIMARY KEY (`Cod_Tip_User`);

--
-- Índices de tabela `Usuario`
--
ALTER TABLE `Usuario`
  ADD PRIMARY KEY (`Cod_Usuario`),
  ADD KEY `Tip_Cod_Tip_User` (`tipoUser`);

--
-- AUTO_INCREMENT de tabelas apagadas
--

--
-- AUTO_INCREMENT de tabela `Baia`
--
ALTER TABLE `Baia`
  MODIFY `Cod_Baia` int(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `Cad_Animal`
--
ALTER TABLE `Cad_Animal`
  MODIFY `Cod_Animal` int(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `Est_Racao`
--
ALTER TABLE `Est_Racao`
  MODIFY `Cod_Estoque` int(4) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de tabela `Tip_User`
--
ALTER TABLE `Tip_User`
  MODIFY `Cod_Tip_User` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de tabela `Usuario`
--
ALTER TABLE `Usuario`
  MODIFY `Cod_Usuario` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Restrições para dumps de tabelas
--

--
-- Restrições para tabelas `Cad_Animal`
--
ALTER TABLE `Cad_Animal`
  ADD CONSTRAINT `Cad_Animal_ibfk_1` FOREIGN KEY (`Baia_Cod_Baia`) REFERENCES `Baia` (`Cod_Baia`),
  ADD CONSTRAINT `Cad_Animal_ibfk_2` FOREIGN KEY (`Est_Cod_Estoque`) REFERENCES `Est_Racao` (`Cod_Estoque`),
  ADD CONSTRAINT `Cad_Animal_ibfk_3` FOREIGN KEY (`Usuario_Cod_Usuario`) REFERENCES `Usuario` (`Cod_Usuario`);

--
-- Restrições para tabelas `Est_Racao`
--
ALTER TABLE `Est_Racao`
  ADD CONSTRAINT `Est_Racao_ibfk_1` FOREIGN KEY (`Usuario_Est_Cod_Usuario`) REFERENCES `Usuario` (`Cod_Usuario`);

--
-- Restrições para tabelas `Usuario`
--
ALTER TABLE `Usuario`
  ADD CONSTRAINT `Usuario_ibfk_1` FOREIGN KEY (`tipoUser`) REFERENCES `Tip_User` (`Cod_Tip_User`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
